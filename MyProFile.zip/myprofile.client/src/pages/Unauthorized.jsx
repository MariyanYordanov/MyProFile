﻿
export default function Unauthorized() {
    return (
        <div className="text-center p-10">
            <h1 className="text-3xl font-bold text-red-600">Нямате достъп до тази страница</h1>
            <p className="mt-4">Моля, свържете се с администратора, ако смятате, че това е грешка.</p>
        </div>
    );
}

