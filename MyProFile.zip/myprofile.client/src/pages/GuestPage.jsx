﻿export default function GuestPage() {
    return (
        <div className="p-4">
            <h1 className="text-2xl font-bold mb-4">Гост</h1>
            <p>Това е публичната част на приложението, достъпна за нерегистрирани потребители. Може да разглеждате, но нямате права за редакция.</p>
        </div>
    );
}