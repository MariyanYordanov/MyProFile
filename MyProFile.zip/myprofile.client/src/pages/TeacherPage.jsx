﻿export default function TeacherPage() {
    return (
        <div className="p-4">
            <h1 className="text-2xl font-bold mb-4">Учителски панел</h1>
            <p>Добре дошли в секцията за учители. Тук ще добавим функционалности като управление на оценки, присъствия и др.</p>
        </div>
    );
}