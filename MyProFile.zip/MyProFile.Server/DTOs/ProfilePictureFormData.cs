﻿public class ProfilePictureFormData
{
    public IFormFile File { get; set; } = null!;
}
